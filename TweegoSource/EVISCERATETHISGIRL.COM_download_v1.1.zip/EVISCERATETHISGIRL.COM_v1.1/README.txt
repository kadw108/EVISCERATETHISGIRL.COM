To play, open index.html in a browser.

The assets folder contains public domain assets that can be used freely.

Have fun!
